#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*PMLogCallback)(void *context, const char *message);
typedef void (*PMDrawingCallback)(
    void *context,
    int32_t object_id,
    const char *kind,
    const char *action,
    const char *property,
    const char *value_json
);

void *pm_runtime_create(PMLogCallback log_callback, PMDrawingCallback drawing_callback, void *context);
int32_t pm_runtime_execute(void *runtime, const char *source);
void pm_runtime_clear_drawings(void *runtime);
void pm_runtime_destroy(void *runtime);

#ifdef __cplusplus
}
#endif

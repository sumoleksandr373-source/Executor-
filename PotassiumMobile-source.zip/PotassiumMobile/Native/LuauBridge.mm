#include "LuauBridge.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <unordered_set>

#ifndef LUA_API
#define LUA_API extern "C"
#endif
#ifndef LUACODE_API
#define LUACODE_API extern "C"
#endif
#include "lua.h"
#include "lualib.h"
#include "luacode.h"

namespace {

constexpr size_t kMaximumScriptBytes = 128 * 1024;
constexpr size_t kMaximumVMMemoryBytes = 64 * 1024 * 1024;
constexpr int kMaximumDrawingObjects = 512;
constexpr auto kExecutionLimit = std::chrono::seconds(2);

struct Runtime {
    lua_State *state = nullptr;
    PMLogCallback logCallback = nullptr;
    PMDrawingCallback drawingCallback = nullptr;
    void *context = nullptr;
    int32_t nextObjectID = 1;
    std::unordered_set<int32_t> activeObjects;
    size_t allocatedBytes = 0;
    std::chrono::steady_clock::time_point deadline;
};

Runtime *runtimeFor(lua_State *state) {
    return static_cast<Runtime *>(lua_getthreaddata(state));
}

void *limitedAllocator(void *context, void *pointer, size_t oldSize, size_t newSize) {
    Runtime *runtime = static_cast<Runtime *>(context);
    if (newSize == 0) {
        if (pointer) {
            std::free(pointer);
            if (runtime) runtime->allocatedBytes -= std::min(runtime->allocatedBytes, oldSize);
        }
        return nullptr;
    }

    // Luau may pass a type tag in oldSize when pointer is null; only subtract
    // a previous allocation when reallocating an existing block.
    const size_t previous = runtime
        ? runtime->allocatedBytes - (pointer ? std::min(runtime->allocatedBytes, oldSize) : 0)
        : 0;
    if (!runtime || newSize > kMaximumVMMemoryBytes - std::min(previous, kMaximumVMMemoryBytes)) {
        return nullptr;
    }

    void *updated = std::realloc(pointer, newSize);
    if (!updated) return nullptr;
    runtime->allocatedBytes = previous + newSize;
    return updated;
}

void emitLog(Runtime *runtime, const std::string &message) {
    if (runtime && runtime->logCallback) {
        runtime->logCallback(runtime->context, message.c_str());
    }
}

void emitDrawing(Runtime *runtime, int32_t objectID, const char *kind,
                 const char *action, const char *property, const char *valueJSON) {
    if (runtime && runtime->drawingCallback) {
        runtime->drawingCallback(runtime->context, objectID,
                                 kind ? kind : "", action ? action : "",
                                 property ? property : "", valueJSON ? valueJSON : "null");
    }
}

std::string jsonNumber(double value) {
    if (!std::isfinite(value)) return "0";
    char buffer[64];
    std::snprintf(buffer, sizeof(buffer), "%.8g", value);
    return buffer;
}

std::string escapeJSONString(const char *value) {
    std::string result = "\"";
    if (value) {
        for (const unsigned char c : std::string(value)) {
            switch (c) {
                case '\\': result += "\\\\"; break;
                case '"': result += "\\\""; break;
                case '\n': result += "\\n"; break;
                case '\r': result += "\\r"; break;
                case '\t': result += "\\t"; break;
                default:
                    if (c < 0x20) {
                        char buffer[7];
                        std::snprintf(buffer, sizeof(buffer), "\\u%04x", c);
                        result += buffer;
                    } else {
                        result += static_cast<char>(c);
                    }
            }
        }
    }
    result += '"';
    return result;
}

std::string valueAsJSON(lua_State *state, int index) {
    const int type = lua_type(state, index);
    switch (type) {
        case LUA_TNIL:
            return "null";
        case LUA_TBOOLEAN:
            return lua_toboolean(state, index) ? "true" : "false";
        case LUA_TNUMBER:
            return jsonNumber(lua_tonumber(state, index));
        case LUA_TSTRING:
            return escapeJSONString(lua_tostring(state, index));
        case LUA_TTABLE: {
            const int absoluteIndex = lua_absindex(state, index);
            lua_getfield(state, absoluteIndex, "__pm_kind");
            const char *kind = lua_tostring(state, -1);
            const std::string kindName = kind ? kind : "";
            lua_pop(state, 1);
            if (kindName == "Vector2") {
                lua_getfield(state, absoluteIndex, "X");
                const double x = lua_tonumber(state, -1);
                lua_pop(state, 1);
                lua_getfield(state, absoluteIndex, "Y");
                const double y = lua_tonumber(state, -1);
                lua_pop(state, 1);
                return "{\"X\":" + jsonNumber(x) + ",\"Y\":" + jsonNumber(y) + "}";
            }
            if (kindName == "Color3") {
                lua_getfield(state, absoluteIndex, "R");
                const double red = lua_tonumber(state, -1);
                lua_pop(state, 1);
                lua_getfield(state, absoluteIndex, "G");
                const double green = lua_tonumber(state, -1);
                lua_pop(state, 1);
                lua_getfield(state, absoluteIndex, "B");
                const double blue = lua_tonumber(state, -1);
                lua_pop(state, 1);
                return "{\"R\":" + jsonNumber(red) +
                       ",\"G\":" + jsonNumber(green) +
                       ",\"B\":" + jsonNumber(blue) + "}";
            }
            return "{}";
        }
        default:
            return "null";
    }
}

int printFunction(lua_State *state) {
    Runtime *runtime = runtimeFor(state);
    const int count = lua_gettop(state);
    std::string output;
    for (int index = 1; index <= count; ++index) {
        if (index > 1) output += "\t";
        const int type = lua_type(state, index);
        if (type == LUA_TSTRING) {
            output += lua_tostring(state, index);
        } else if (type == LUA_TNUMBER) {
            output += jsonNumber(lua_tonumber(state, index));
        } else if (type == LUA_TBOOLEAN) {
            output += lua_toboolean(state, index) ? "true" : "false";
        } else {
            output += luaL_typename(state, index);
        }
    }
    emitLog(runtime, output);
    return 0;
}

void pushVector2Value(lua_State *state, double x, double y) {
    lua_createtable(state, 0, 3);
    lua_pushstring(state, "Vector2");
    lua_setfield(state, -2, "__pm_kind");
    lua_pushnumber(state, x);
    lua_setfield(state, -2, "X");
    lua_pushnumber(state, y);
    lua_setfield(state, -2, "Y");
    lua_setreadonly(state, -1, 1);
}

void pushColor3Value(lua_State *state, double red, double green, double blue) {
    lua_createtable(state, 0, 4);
    lua_pushstring(state, "Color3");
    lua_setfield(state, -2, "__pm_kind");
    lua_pushnumber(state, red);
    lua_setfield(state, -2, "R");
    lua_pushnumber(state, green);
    lua_setfield(state, -2, "G");
    lua_pushnumber(state, blue);
    lua_setfield(state, -2, "B");
    lua_setreadonly(state, -1, 1);
}

int vector2New(lua_State *state) {
    const double x = luaL_checknumber(state, 1);
    const double y = luaL_checknumber(state, 2);
    pushVector2Value(state, x, y);
    return 1;
}

int color3FromRGB(lua_State *state) {
    const double red = std::clamp(luaL_checknumber(state, 1) / 255.0, 0.0, 1.0);
    const double green = std::clamp(luaL_checknumber(state, 2) / 255.0, 0.0, 1.0);
    const double blue = std::clamp(luaL_checknumber(state, 3) / 255.0, 0.0, 1.0);
    pushColor3Value(state, red, green, blue);
    return 1;
}

bool pushDrawingMetadata(lua_State *state, int objectIndex) {
    return lua_getmetatable(state, objectIndex) != 0;
}

int drawingObjectIndex(lua_State *state) {
    luaL_checktype(state, 1, LUA_TTABLE);
    const char *key = luaL_checkstring(state, 2);
    if (std::strcmp(key, "Remove") == 0 || std::strcmp(key, "Destroy") == 0) {
        lua_pushcfunction(state, [](lua_State *inner) -> int {
            luaL_checktype(inner, 1, LUA_TTABLE);
            if (!pushDrawingMetadata(inner, 1)) {
                luaL_error(inner, "invalid Drawing object");
                return 0;
            }
            lua_getfield(inner, -1, "__pm_id");
            const int32_t objectID = static_cast<int32_t>(lua_tointeger(inner, -1));
            lua_pop(inner, 1);
            lua_getfield(inner, -1, "__pm_type");
            const char *kind = lua_tostring(inner, -1);
            Runtime *runtime = runtimeFor(inner);
            if (runtime && runtime->activeObjects.erase(objectID) > 0) {
                emitDrawing(runtime, objectID, kind, "removed", "", "null");
            }
            return 0;
        }, "DrawingObject.Remove");
        return 1;
    }

    if (!pushDrawingMetadata(state, 1)) return 0;
    lua_getfield(state, -1, "__pm_props");
    lua_getfield(state, -1, key);
    return 1;
}

int drawingObjectNewIndex(lua_State *state) {
    luaL_checktype(state, 1, LUA_TTABLE);
    const char *property = luaL_checkstring(state, 2);
    if (!pushDrawingMetadata(state, 1)) {
        luaL_error(state, "invalid Drawing object");
        return 0;
    }
    lua_getfield(state, -1, "__pm_props");
    lua_pushvalue(state, 2);
    lua_pushvalue(state, 3);
    lua_settable(state, -3);
    lua_pop(state, 1); // properties table; metatable remains on the stack

    lua_getfield(state, -1, "__pm_id");
    const int32_t objectID = static_cast<int32_t>(lua_tointeger(state, -1));
    lua_pop(state, 1);
    lua_getfield(state, -1, "__pm_type");
    const char *kindValue = lua_tostring(state, -1);
    const std::string kind = kindValue ? kindValue : "";
    const std::string serialized = valueAsJSON(state, 3);
    emitDrawing(runtimeFor(state), objectID, kind.c_str(), "changed", property, serialized.c_str());
    return 0;
}

int drawingNew(lua_State *state) {
    Runtime *runtime = runtimeFor(state);
    const char *kind = luaL_checkstring(state, 1);
    const bool supported = std::strcmp(kind, "Line") == 0 ||
        std::strcmp(kind, "Square") == 0 || std::strcmp(kind, "Circle") == 0 ||
        std::strcmp(kind, "Text") == 0 || std::strcmp(kind, "Triangle") == 0 ||
        std::strcmp(kind, "Quad") == 0;
    if (!supported) {
        luaL_error(state, "unsupported Drawing type '%s'", kind);
        return 0;
    }
    if (!runtime || runtime->activeObjects.size() >= kMaximumDrawingObjects) {
        luaL_error(state, "Drawing object limit reached");
        return 0;
    }

    const int32_t objectID = runtime->nextObjectID++;
    runtime->activeObjects.insert(objectID);
    lua_createtable(state, 0, 0); // public proxy table
    lua_createtable(state, 0, 7); // private metadata stored in its protected metatable
    const int metadataIndex = lua_gettop(state);
    lua_pushinteger(state, objectID);
    lua_setfield(state, metadataIndex, "__pm_id");
    lua_pushstring(state, kind);
    lua_setfield(state, metadataIndex, "__pm_type");
    lua_createtable(state, 0, 16);
    const int propertiesIndex = lua_gettop(state);
    lua_pushboolean(state, 1);
    lua_setfield(state, propertiesIndex, "Visible");
    lua_pushnumber(state, 0);
    lua_setfield(state, propertiesIndex, "Transparency");
    lua_pushnumber(state, 1);
    lua_setfield(state, propertiesIndex, "Thickness");
    lua_pushboolean(state, 0);
    lua_setfield(state, propertiesIndex, "Filled");
    lua_pushnumber(state, 18);
    lua_setfield(state, propertiesIndex, "TextSize");
    lua_pushstring(state, "");
    lua_setfield(state, propertiesIndex, "Text");
    lua_pushnumber(state, 34);
    lua_setfield(state, propertiesIndex, "Radius");
    lua_pushboolean(state, 0);
    lua_setfield(state, propertiesIndex, "Center");
    pushVector2Value(state, 0, 0);
    lua_setfield(state, propertiesIndex, "Position");
    pushVector2Value(state, 100, 60);
    lua_setfield(state, propertiesIndex, "Size");
    pushVector2Value(state, 0, 0);
    lua_setfield(state, propertiesIndex, "From");
    pushVector2Value(state, 100, 60);
    lua_setfield(state, propertiesIndex, "To");
    pushColor3Value(state, 1, 1, 1);
    lua_setfield(state, propertiesIndex, "Color");
    lua_setfield(state, metadataIndex, "__pm_props");
    lua_pushcfunction(state, drawingObjectIndex, "DrawingObject.__index");
    lua_setfield(state, metadataIndex, "__index");
    lua_pushcfunction(state, drawingObjectNewIndex, "DrawingObject.__newindex");
    lua_setfield(state, metadataIndex, "__newindex");
    lua_pushstring(state, "DrawingObject");
    lua_setfield(state, metadataIndex, "__metatable");
    lua_setmetatable(state, -2);

    emitDrawing(runtime, objectID, kind, "created", "", "{}");
    return 1;
}

bool isActiveDrawingObject(lua_State *state, int index) {
    if (!lua_istable(state, index)) return false;
    if (!pushDrawingMetadata(state, index)) return false;
    lua_getfield(state, -1, "__pm_id");
    const int32_t objectID = static_cast<int32_t>(lua_tointeger(state, -1));
    lua_pop(state, 2);
    Runtime *runtime = runtimeFor(state);
    return runtime && runtime->activeObjects.count(objectID) > 0;
}

int isRenderObject(lua_State *state) {
    lua_pushboolean(state, isActiveDrawingObject(state, 1) ? 1 : 0);
    return 1;
}

int getRenderProperty(lua_State *state) {
    luaL_checktype(state, 1, LUA_TTABLE);
    if (!isActiveDrawingObject(state, 1)) {
        luaL_error(state, "expected an active Drawing object");
        return 0;
    }
    const char *property = luaL_checkstring(state, 2);
    pushDrawingMetadata(state, 1);
    lua_getfield(state, -1, "__pm_props");
    lua_getfield(state, -1, property);
    return 1;
}

int setRenderProperty(lua_State *state) {
    luaL_checktype(state, 1, LUA_TTABLE);
    if (!isActiveDrawingObject(state, 1)) {
        luaL_error(state, "expected an active Drawing object");
        return 0;
    }
    const char *property = luaL_checkstring(state, 2);
    lua_pushvalue(state, 3);
    lua_setfield(state, 1, property);
    return 0;
}

int clearDrawCache(lua_State *state) {
    Runtime *runtime = runtimeFor(state);
    emitDrawing(runtime, 0, "", "clear", "", "null");
    if (runtime) runtime->activeObjects.clear();
    return 0;
}

void executionInterrupt(lua_State *state, int) {
    Runtime *runtime = runtimeFor(state);
    if (runtime && std::chrono::steady_clock::now() > runtime->deadline) {
        luaL_error(state, "execution time limit exceeded (2 seconds)");
    }
}

void setGlobalFunction(lua_State *state, const char *name, lua_CFunction function) {
    lua_pushcfunction(state, function, name);
    lua_setglobal(state, name);
}

void registerDrawingAPI(lua_State *state) {
    lua_createtable(state, 0, 1);
    lua_pushcfunction(state, drawingNew, "Drawing.new");
    lua_setfield(state, -2, "new");
    lua_setreadonly(state, -1, 1);
    lua_setglobal(state, "Drawing");

    lua_createtable(state, 0, 1);
    lua_pushcfunction(state, vector2New, "Vector2.new");
    lua_setfield(state, -2, "new");
    lua_setreadonly(state, -1, 1);
    lua_setglobal(state, "Vector2");

    lua_createtable(state, 0, 1);
    lua_pushcfunction(state, color3FromRGB, "Color3.fromRGB");
    lua_setfield(state, -2, "fromRGB");
    lua_setreadonly(state, -1, 1);
    lua_setglobal(state, "Color3");

    setGlobalFunction(state, "isrenderobj", isRenderObject);
    setGlobalFunction(state, "getrenderproperty", getRenderProperty);
    setGlobalFunction(state, "setrenderproperty", setRenderProperty);
    setGlobalFunction(state, "cleardrawcache", clearDrawCache);
    setGlobalFunction(state, "print", printFunction);
    setGlobalFunction(state, "warn", printFunction);
}

void removeUnsafeLibraries(lua_State *state) {
    const char *blocked[] = {
        "io", "os", "debug", "package", "require", "dofile", "loadfile",
        "loadstring", "coroutine", "rawset"
    };
    for (const char *name : blocked) {
        lua_pushnil(state);
        lua_setglobal(state, name);
    }
}

void createSandbox(lua_State *state) {
    luaL_openlibs(state);
    registerDrawingAPI(state);
    removeUnsafeLibraries(state);
    luaL_sandbox(state);
}

} // namespace

extern "C" void *pm_runtime_create(PMLogCallback logCallback,
                                    PMDrawingCallback drawingCallback,
                                    void *context) {
    Runtime *runtime = new Runtime();
    runtime->logCallback = logCallback;
    runtime->drawingCallback = drawingCallback;
    runtime->context = context;
    runtime->state = lua_newstate(limitedAllocator, runtime);
    if (!runtime->state) {
        delete runtime;
        return nullptr;
    }
    createSandbox(runtime->state);
    return runtime;
}

extern "C" int32_t pm_runtime_execute(void *opaqueRuntime, const char *source) {
    Runtime *runtime = static_cast<Runtime *>(opaqueRuntime);
    if (!runtime || !runtime->state || !source) return -1;
    const size_t sourceLength = std::strlen(source);
    if (sourceLength > kMaximumScriptBytes) {
        emitLog(runtime, "Script rejected: source exceeds 128 KB.");
        return -2;
    }

    runtime->deadline = std::chrono::steady_clock::now() + kExecutionLimit;
    lua_State *mainState = runtime->state;
    lua_settop(mainState, 0);
    lua_State *thread = lua_newthread(mainState);
    if (!thread) {
        emitLog(runtime, "Runtime error: could not create a Luau thread.");
        lua_settop(mainState, 0);
        return -3;
    }

    lua_setthreaddata(thread, runtime);
    lua_callbacks(thread)->interrupt = executionInterrupt;
    luaL_sandboxthread(thread);

    const std::string sourceCopy(source, sourceLength);
    size_t bytecodeSize = 0;
    char *bytecode = luau_compile(sourceCopy.data(), sourceCopy.size(), nullptr, &bytecodeSize);
    if (!bytecode || bytecodeSize == 0) {
        std::free(bytecode);
        emitLog(runtime, "Compile error: compiler returned no bytecode.");
        lua_settop(thread, 0);
        lua_settop(mainState, 0);
        return -4;
    }

    const int loadResult = luau_load(thread, "=PotassiumMobile", bytecode, bytecodeSize, 0);
    std::free(bytecode);
    if (loadResult != 0) {
        const char *message = lua_tostring(thread, -1);
        emitLog(runtime, message ? message : "Bytecode load error.");
        lua_settop(thread, 0);
        lua_settop(mainState, 0);
        return -5;
    }

    const int callResult = lua_pcall(thread, 0, 0, 0);
    if (callResult != 0) {
        const char *message = lua_tostring(thread, -1);
        emitLog(runtime, message ? message : "Runtime error.");
        lua_settop(thread, 0);
        lua_settop(mainState, 0);
        return -6;
    }

    lua_settop(thread, 0);
    lua_settop(mainState, 0);
    return 0;
}

extern "C" void pm_runtime_destroy(void *opaqueRuntime) {
    Runtime *runtime = static_cast<Runtime *>(opaqueRuntime);
    if (!runtime) return;
    if (runtime->state) lua_close(runtime->state);
    delete runtime;
}

extern "C" void pm_runtime_clear_drawings(void *opaqueRuntime) {
    Runtime *runtime = static_cast<Runtime *>(opaqueRuntime);
    if (!runtime) return;
    runtime->activeObjects.clear();
    emitDrawing(runtime, 0, "", "clear", "", "null");
}

#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VENDOR_DIR="$ROOT_DIR/Vendor"
SOURCE_DIR="$VENDOR_DIR/luau"
BUILD_ROOT="$VENDOR_DIR/build-ios"
OUTPUT_DIR="$ROOT_DIR/Frameworks"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This script must run on macOS with Xcode Command Line Tools installed." >&2
  exit 1
fi

command -v cmake >/dev/null || { echo "cmake is required (brew install cmake)." >&2; exit 1; }
command -v xcodebuild >/dev/null || { echo "xcodebuild is required; install Xcode/Command Line Tools." >&2; exit 1; }

if [[ ! -d "$SOURCE_DIR/.git" ]]; then
  mkdir -p "$VENDOR_DIR"
  rm -rf "$SOURCE_DIR"
  git clone --depth 1 --branch 0.748 https://github.com/luau-lang/luau.git "$SOURCE_DIR"
fi

build_slice() {
  local slice="$1"
  local sysroot="$2"
  local architectures="$3"
  local build_dir="$BUILD_ROOT/$slice"
  cmake -S "$SOURCE_DIR" -B "$build_dir" -G "Unix Makefiles" \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_SYSTEM_NAME=iOS \
    -DCMAKE_OSX_SYSROOT="$sysroot" \
    -DCMAKE_OSX_ARCHITECTURES="$architectures" \
    -DCMAKE_OSX_DEPLOYMENT_TARGET=16.0 \
    -DLUAU_BUILD_CLI=OFF \
    -DLUAU_BUILD_TESTS=OFF \
    -DLUAU_BUILD_WEB=OFF \
    -DLUAU_BUILD_SHARED=OFF \
    -DLUAU_EXTERN_C=ON \
    -DCMAKE_POSITION_INDEPENDENT_CODE=ON
  cmake --build "$build_dir" --config Release --target Luau.Common Luau.Ast Luau.Bytecode Luau.VM Luau.Compiler --parallel
  mkdir -p "$build_dir/combined"
  libtool -static -o "$build_dir/combined/libLuauRuntime.a" \
    "$build_dir/libLuau.VM.a" \
    "$build_dir/libLuau.Compiler.a" \
    "$build_dir/libLuau.Bytecode.a" \
    "$build_dir/libLuau.Ast.a" \
    "$build_dir/libLuau.Common.a"
}

build_slice iphoneos iphoneos arm64
build_slice iphonesimulator iphonesimulator "arm64;x86_64"

HEADERS_DIR="$BUILD_ROOT/headers"
mkdir -p "$HEADERS_DIR"
cp "$SOURCE_DIR/VM/include/lua.h" "$HEADERS_DIR/"
cp "$SOURCE_DIR/VM/include/lualib.h" "$HEADERS_DIR/"
cp "$SOURCE_DIR/VM/include/luaconf.h" "$HEADERS_DIR/"
cp "$SOURCE_DIR/Compiler/include/luacode.h" "$HEADERS_DIR/"

rm -rf "$OUTPUT_DIR/LuauRuntime.xcframework"
xcodebuild -create-xcframework \
  -library "$BUILD_ROOT/iphoneos/combined/libLuauRuntime.a" -headers "$HEADERS_DIR" \
  -library "$BUILD_ROOT/iphonesimulator/combined/libLuauRuntime.a" -headers "$HEADERS_DIR" \
  -output "$OUTPUT_DIR/LuauRuntime.xcframework"

echo "Built: $OUTPUT_DIR/LuauRuntime.xcframework"

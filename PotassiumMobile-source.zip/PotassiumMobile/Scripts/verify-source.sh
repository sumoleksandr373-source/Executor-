#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if command -v swiftc >/dev/null 2>&1; then
  swiftc -frontend -parse "$ROOT_DIR"/PotassiumMobile/*.swift
  echo "✓ Swift syntax"
else
  echo "! swiftc not found; skipped Swift parsing" >&2
fi

bash -n "$ROOT_DIR/Scripts/build-luau-ios.sh"
echo "✓ Build script syntax"

if command -v python3 >/dev/null 2>&1; then
  python3 - "$ROOT_DIR/project.yml" <<'PY'
import sys
from pathlib import Path
try:
    import yaml
except ImportError:
    print("! PyYAML unavailable; skipped project.yml parse")
    raise SystemExit(0)
project = yaml.safe_load(Path(sys.argv[1]).read_text(encoding="utf-8"))
assert project["name"] == "PotassiumMobile"
assert project["targets"]["PotassiumMobile"]["platform"] == "iOS"
print("✓ XcodeGen YAML")
PY
fi

if [[ -d "$ROOT_DIR/Vendor/luau/VM/include" && -d "$ROOT_DIR/Vendor/luau/Compiler/include" ]] && command -v clang++ >/dev/null 2>&1; then
  clang++ -std=c++17 -DLUA_USE_LONGJMP=1 -fsyntax-only \
    -I "$ROOT_DIR/Native" \
    -I "$ROOT_DIR/Vendor/luau/VM/include" \
    -I "$ROOT_DIR/Vendor/luau/Compiler/include" \
    "$ROOT_DIR/Native/LuauBridge.mm"
  echo "✓ Luau bridge C++ syntax"
else
  echo "! Luau source headers or clang++ unavailable; skipped bridge compile check" >&2
fi

echo "Source checks completed. This script does not replace an Xcode iOS build or device test."

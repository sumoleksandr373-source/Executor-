# Third-party notices

The app's embedded scripting runtime is built from the official Luau project: https://github.com/luau-lang/luau (release tag `0.748`).

Luau is distributed under the MIT License. Its source is fetched at build time by `Scripts/build-luau-ios.sh`; the fetched source tree and its license are kept under `Vendor/luau` and are not pre-bundled in this source archive. Keep the upstream `LICENSE.txt` with redistributed builds.

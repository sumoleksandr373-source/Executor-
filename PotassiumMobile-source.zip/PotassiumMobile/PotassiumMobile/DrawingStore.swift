import Foundation
import Combine
import Dispatch

private struct SendableRuntimeHandle: @unchecked Sendable {
    let pointer: UnsafeMutableRawPointer
}

final class DrawingStore: ObservableObject {
    @Published private(set) var objects: [DrawingObject] = []
    @Published private(set) var consoleLines: [String] = ["Potassium Mobile ready."]
    @Published var source = DrawingStore.sampleScript
    @Published private(set) var isRunning = false
    @Published private(set) var runtimeAvailable = false
    @Published private(set) var savedScriptExists = false

    private var runtime: UnsafeMutableRawPointer?
    private let consoleLimit = 250

    init() {
        let context = Unmanaged.passUnretained(self).toOpaque()
        runtime = pm_runtime_create(pmSwiftLogCallback, pmSwiftDrawingCallback, context)
        runtimeAvailable = runtime != nil
        refreshSavedScriptState()
        if !runtimeAvailable {
            appendConsole("Luau VM could not be initialized. Check the app build and available memory.")
        }
    }

    deinit {
        if let runtime {
            pm_runtime_destroy(runtime)
        }
    }

    func run() {
        guard let runtime, !isRunning else { return }
        isRunning = true
        appendConsole("▶ Running script…")
        let script = source
        let runtimeHandle = SendableRuntimeHandle(pointer: runtime)

        // Keep the store alive until the VM call and its completion callback finish.
        // The native bridge holds an unretained context pointer back to this object.
        DispatchQueue.global(qos: .userInitiated).async { [self, runtimeHandle] in
            let result = script.withCString { sourcePointer in
                pm_runtime_execute(runtimeHandle.pointer, sourcePointer)
            }
            DispatchQueue.main.async {
                self.isRunning = false
                if result == 0 {
                    self.appendConsole("✓ Script finished")
                } else {
                    self.appendConsole("✕ Script failed (code \(result))")
                }
            }
        }
    }

    func clearDrawing() {
        guard !isRunning else { return }
        guard let runtime else {
            objects.removeAll()
            return
        }
        pm_runtime_clear_drawings(runtime)
    }

    func saveScript() {
        do {
            let destination = try savedScriptURL(createDirectory: true)
            try source.write(to: destination, atomically: true, encoding: .utf8)
            savedScriptExists = true
            appendConsole("Saved: Documents/Scripts/Untitled.luau")
        } catch {
            appendConsole("Save error: \(error.localizedDescription)")
        }
    }

    func loadSavedScript() {
        do {
            let fileURL = try savedScriptURL(createDirectory: false)
            source = try String(contentsOf: fileURL, encoding: .utf8)
            appendConsole("Loaded: Documents/Scripts/Untitled.luau")
        } catch {
            appendConsole("Load error: \(error.localizedDescription)")
        }
    }

    func clearConsole() {
        consoleLines.removeAll()
    }

    private func refreshSavedScriptState() {
        guard let fileURL = try? savedScriptURL(createDirectory: false) else {
            savedScriptExists = false
            return
        }
        savedScriptExists = FileManager.default.fileExists(atPath: fileURL.path)
    }

    private func savedScriptURL(createDirectory: Bool) throws -> URL {
        let documents = try FileManager.default.url(
            for: .documentDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let directory = documents.appendingPathComponent("Scripts", isDirectory: true)
        if createDirectory {
            try FileManager.default.createDirectory(
                at: directory,
                withIntermediateDirectories: true
            )
        }
        return directory.appendingPathComponent("Untitled.luau")
    }

    func appendConsole(_ line: String) {
        consoleLines.append(line)
        if consoleLines.count > consoleLimit {
            consoleLines.removeFirst(consoleLines.count - consoleLimit)
        }
    }

    fileprivate func receiveLog(_ message: String) {
        DispatchQueue.main.async { [weak self] in
            self?.appendConsole(message)
        }
    }

    fileprivate func receiveDrawing(
        id: Int,
        kindName: String,
        action: String,
        property: String,
        valueJSON: String
    ) {
        DispatchQueue.main.async { [weak self] in
            self?.applyDrawingEvent(
                id: id,
                kindName: kindName,
                action: action,
                property: property,
                valueJSON: valueJSON
            )
        }
    }

    private func applyDrawingEvent(
        id: Int,
        kindName: String,
        action: String,
        property: String,
        valueJSON: String
    ) {
        if action == "clear" {
            objects.removeAll()
            return
        }
        if action == "created" {
            guard let kind = DrawingKind(rawValue: kindName) else {
                appendConsole("Drawing.new: unsupported type '\(kindName)'")
                return
            }
            objects.append(DrawingObject(id: id, kind: kind))
            return
        }
        if action == "removed" {
            objects.removeAll { $0.id == id }
            return
        }
        guard action == "changed",
              let index = objects.firstIndex(where: { $0.id == id }),
              let data = valueJSON.data(using: .utf8),
              let value = try? JSONSerialization.jsonObject(with: data, options: [.fragmentsAllowed]) else {
            return
        }
        apply(value: value, property: property, to: &objects[index])
    }

    private func apply(value: Any, property: String, to object: inout DrawingObject) {
        switch property.lowercased() {
        case "visible":
            if let value = value as? Bool { object.visible = value }
        case "position":
            if let point = point(from: value) { object.position = point }
        case "size":
            if let size = size(from: value) { object.size = size }
        case "from":
            if let point = point(from: value) { object.from = point }
        case "to":
            if let point = point(from: value) { object.to = point }
        case "color":
            if let color = color(from: value) { object.color = color.clamped() }
        case "transparency":
            if let number = finiteNumber(from: value) {
                object.transparency = min(max(number, 0), 1)
            }
        case "thickness":
            if let number = finiteNumber(from: value) {
                object.thickness = min(max(number, 0.1), 100)
            }
        case "filled":
            if let value = value as? Bool { object.filled = value }
        case "radius":
            if let number = finiteNumber(from: value) {
                object.radius = min(max(number, 0), 10_000)
            }
        case "text":
            if let value = value as? String { object.text = String(value.prefix(2_048)) }
        case "textsize":
            if let number = finiteNumber(from: value) {
                object.textSize = min(max(number, 8), 200)
            }
        case "center":
            if let value = value as? Bool { object.centered = value }
        default:
            break
        }
    }

    private func finiteNumber(from value: Any) -> Double? {
        guard let number = value as? NSNumber else { return nil }
        let result = number.doubleValue
        return result.isFinite ? result : nil
    }

    private func point(from value: Any) -> DrawingPoint? {
        guard let dictionary = value as? [String: Any],
              let xValue = dictionary["X"],
              let yValue = dictionary["Y"],
              let rawX = finiteNumber(from: xValue),
              let rawY = finiteNumber(from: yValue) else { return nil }
        return DrawingPoint(x: min(max(rawX, -10_000), 10_000),
                            y: min(max(rawY, -10_000), 10_000))
    }

    private func size(from value: Any) -> DrawingSize? {
        guard let dictionary = value as? [String: Any],
              let widthValue = dictionary["X"],
              let heightValue = dictionary["Y"],
              let rawWidth = finiteNumber(from: widthValue),
              let rawHeight = finiteNumber(from: heightValue) else { return nil }
        return DrawingSize(width: min(max(rawWidth, 0), 10_000),
                           height: min(max(rawHeight, 0), 10_000))
    }

    private func color(from value: Any) -> DrawingColor? {
        guard let dictionary = value as? [String: Any],
              let redValue = dictionary["R"],
              let greenValue = dictionary["G"],
              let blueValue = dictionary["B"],
              let red = finiteNumber(from: redValue),
              let green = finiteNumber(from: greenValue),
              let blue = finiteNumber(from: blueValue) else { return nil }
        return DrawingColor(red: red, green: green, blue: blue)
    }

    static let sampleScript = #"""
local line = Drawing.new("Line")
line.From = Vector2.new(24, 44)
line.To = Vector2.new(280, 44)
line.Color = Color3.fromRGB(76, 166, 255)
line.Thickness = 3

local box = Drawing.new("Square")
box.Position = Vector2.new(42, 76)
box.Size = Vector2.new(150, 76)
box.Color = Color3.fromRGB(58, 205, 148)
box.Thickness = 2
box.Filled = false

local label = Drawing.new("Text")
label.Position = Vector2.new(42, 174)
label.Text = "Hello from Luau"
label.Color = Color3.fromRGB(242, 245, 250)
label.TextSize = 18

print("Created", isrenderobj(line), "drawing objects")
"""#
}

@_cdecl("pmSwiftLogCallback")
func pmSwiftLogCallback(_ context: UnsafeMutableRawPointer?, _ message: UnsafePointer<CChar>?) {
    guard let context, let message else { return }
    let store = Unmanaged<DrawingStore>.fromOpaque(context).takeUnretainedValue()
    store.receiveLog(String(cString: message))
}

@_cdecl("pmSwiftDrawingCallback")
func pmSwiftDrawingCallback(
    _ context: UnsafeMutableRawPointer?,
    _ objectID: Int32,
    _ kind: UnsafePointer<CChar>?,
    _ action: UnsafePointer<CChar>?,
    _ property: UnsafePointer<CChar>?,
    _ valueJSON: UnsafePointer<CChar>?
) {
    guard let context else { return }
    let store = Unmanaged<DrawingStore>.fromOpaque(context).takeUnretainedValue()
    store.receiveDrawing(
        id: Int(objectID),
        kindName: kind != nil ? String(cString: kind!) : "",
        action: action != nil ? String(cString: action!) : "",
        property: property != nil ? String(cString: property!) : "",
        valueJSON: valueJSON != nil ? String(cString: valueJSON!) : "null"
    )
}

import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var store: DrawingStore
    @State private var selectedTab = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            editorTab
                .tabItem { Label("Editor", systemImage: "chevron.left.forwardslash.chevron.right") }
                .tag(0)
            drawingTab
                .tabItem { Label("Drawing", systemImage: "scribble.variable") }
                .tag(1)
            filesTab
                .tabItem { Label("Files", systemImage: "folder") }
                .tag(2)
        }
        .tint(Color(red: 0.34, green: 0.70, blue: 1.0))
        .background(Color(red: 0.035, green: 0.045, blue: 0.06))
    }

    private var editorTab: some View {
        NavigationStack {
            VStack(spacing: 12) {
                header
                HStack {
                    Text("SCRIPT.LUAU")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .tracking(1.2)
                        .foregroundStyle(.secondary)
                    Spacer()
                    Button {
                        store.saveScript()
                    } label: {
                        Label("Save", systemImage: "square.and.arrow.down")
                            .font(.system(size: 12, weight: .semibold))
                    }
                    .buttonStyle(.bordered)
                    .tint(.white.opacity(0.7))
                    Button {
                        store.run()
                    } label: {
                        Label(store.isRunning ? "Running" : "Run", systemImage: store.isRunning ? "hourglass" : "play.fill")
                            .font(.system(size: 12, weight: .bold))
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(Color(red: 0.18, green: 0.52, blue: 0.82))
                    .disabled(store.isRunning || !store.runtimeAvailable)
                }
                .padding(.horizontal, 14)

                TextEditor(text: $store.source)
                    .font(.system(size: 13, weight: .regular, design: .monospaced))
                    .scrollContentBackground(.hidden)
                    .foregroundStyle(Color(red: 0.84, green: 0.88, blue: 0.93))
                    .tint(Color(red: 0.39, green: 0.73, blue: 1.0))
                    .padding(10)
                    .background(Color(red: 0.06, green: 0.075, blue: 0.095))
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay {
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .stroke(Color.white.opacity(0.07), lineWidth: 1)
                    }
                    .padding(.horizontal, 12)

                consolePanel
                    .frame(height: 132)
                    .padding(.horizontal, 12)
            }
            .padding(.top, 8)
            .background(Color(red: 0.035, green: 0.045, blue: 0.06))
            .toolbar(.hidden, for: .navigationBar)
        }
    }

    private var header: some View {
        HStack(spacing: 11) {
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(Color(red: 0.13, green: 0.27, blue: 0.39))
                Image(systemName: "terminal.fill")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(Color(red: 0.42, green: 0.76, blue: 1.0))
            }
            .frame(width: 38, height: 38)
            VStack(alignment: .leading, spacing: 2) {
                Text("POTASSIUM")
                    .font(.system(size: 15, weight: .heavy, design: .rounded))
                    .tracking(1.8)
                    .foregroundStyle(.white)
                Text("MOBILE LUAU LAB")
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .tracking(1.2)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Circle()
                .fill(store.runtimeAvailable ? Color.green : Color.orange)
                .frame(width: 7, height: 7)
            Text(store.runtimeAvailable ? "VM READY" : "VM OFFLINE")
                .font(.system(size: 9, weight: .bold, design: .monospaced))
                .foregroundStyle(.secondary)
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 4)
    }

    private var consolePanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("CONSOLE")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .tracking(1.2)
                    .foregroundStyle(.secondary)
                Spacer()
                Button("Clear") { store.clearConsole() }
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(.secondary)
            }
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 4) {
                    ForEach(Array(store.consoleLines.enumerated()), id: \.offset) { entry in
                        Text(entry.element)
                            .font(.system(size: 11, design: .monospaced))
                            .foregroundStyle(entry.element.hasPrefix("✕") ? .red : Color.white.opacity(0.76))
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
            }
        }
        .padding(12)
        .background(Color(red: 0.06, green: 0.075, blue: 0.095))
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(Color.white.opacity(0.07), lineWidth: 1)
        }
    }

    private var drawingTab: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 14) {
                sectionTitle("DRAWING PREVIEW", subtitle: "Native iOS Canvas renderer")
                DrawingCanvasView()
                    .frame(height: 340)
                    .padding(.horizontal, 14)
                HStack {
                    Text("ACTIVE OBJECTS")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .tracking(1.1)
                        .foregroundStyle(.secondary)
                    Spacer()
                    Text("\(store.objects.count)")
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                        .foregroundStyle(.white)
                    Button("Clear canvas") { store.clearDrawing() }
                        .font(.system(size: 11, weight: .medium))
                        .disabled(store.isRunning || store.objects.isEmpty)
                }
                .padding(.horizontal, 16)
                ScrollView {
                    LazyVStack(spacing: 7) {
                        ForEach(store.objects) { object in
                            HStack(spacing: 10) {
                                Image(systemName: icon(for: object.kind))
                                    .foregroundStyle(Color(red: object.color.red, green: object.color.green, blue: object.color.blue))
                                    .frame(width: 28)
                                Text(object.kind.rawValue)
                                    .font(.system(size: 12, weight: .semibold, design: .monospaced))
                                Spacer()
                                Text("#\(object.id)")
                                    .font(.system(size: 10, design: .monospaced))
                                    .foregroundStyle(.secondary)
                                Circle()
                                    .fill(object.visible ? Color.green : Color.gray)
                                    .frame(width: 6, height: 6)
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 10)
                            .background(Color.white.opacity(0.045))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                        }
                    }
                    .padding(.horizontal, 14)
                }
            }
            .padding(.top, 16)
            .background(Color(red: 0.035, green: 0.045, blue: 0.06))
            .toolbar(.hidden, for: .navigationBar)
        }
    }

    private var filesTab: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 16) {
                sectionTitle("SCRIPT FILES", subtitle: "Local files stored inside the app")
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Label("Untitled.luau", systemImage: "doc.text")
                            .font(.system(size: 14, weight: .semibold, design: .monospaced))
                        Spacer()
                        Text(store.savedScriptExists ? "SAVED" : "NOT SAVED")
                            .font(.system(size: 9, weight: .bold, design: .monospaced))
                            .foregroundStyle(store.savedScriptExists ? Color.green : Color.gray)
                    }
                    Text("Local app file: Documents/Scripts/Untitled.luau")
                        .font(.system(size: 12))
                        .foregroundStyle(.secondary)
                    Button {
                        store.saveScript()
                    } label: {
                        Label("Save current script", systemImage: "square.and.arrow.down")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(Color(red: 0.18, green: 0.52, blue: 0.82))
                    Button {
                        store.loadSavedScript()
                        selectedTab = 0
                    } label: {
                        Label("Load saved script", systemImage: "arrow.down.doc")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                    .disabled(!store.savedScriptExists)
                }
                .padding(14)
                .background(Color.white.opacity(0.05))
                .clipShape(RoundedRectangle(cornerRadius: 14))
                Spacer()
            }
            .padding(16)
            .background(Color(red: 0.035, green: 0.045, blue: 0.06))
            .toolbar(.hidden, for: .navigationBar)
        }
    }

    private func sectionTitle(_ title: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.system(size: 16, weight: .heavy, design: .rounded))
                .tracking(1.1)
                .foregroundStyle(.white)
            Text(subtitle)
                .font(.system(size: 11, design: .monospaced))
                .foregroundStyle(.secondary)
        }
        .padding(.horizontal, 16)
    }

    private func icon(for kind: DrawingKind) -> String {
        switch kind {
        case .line: return "line.diagonal"
        case .square: return "square"
        case .circle: return "circle"
        case .text: return "textformat"
        case .triangle: return "triangle"
        case .quad: return "diamond"
        }
    }
}

import Foundation

struct DrawingPoint: Equatable, Codable {
    var x: Double
    var y: Double

    static let zero = DrawingPoint(x: 0, y: 0)
}

struct DrawingSize: Equatable, Codable {
    var width: Double
    var height: Double

    static let zero = DrawingSize(width: 0, height: 0)
}

struct DrawingColor: Equatable, Codable {
    var red: Double
    var green: Double
    var blue: Double

    static let white = DrawingColor(red: 1, green: 1, blue: 1)
    static let blue = DrawingColor(red: 0.25, green: 0.62, blue: 1)

    func clamped() -> DrawingColor {
        DrawingColor(
            red: min(max(red, 0), 1),
            green: min(max(green, 0), 1),
            blue: min(max(blue, 0), 1)
        )
    }
}

enum DrawingKind: String, CaseIterable, Codable {
    case line = "Line"
    case square = "Square"
    case circle = "Circle"
    case text = "Text"
    case triangle = "Triangle"
    case quad = "Quad"
}

struct DrawingObject: Identifiable, Equatable {
    let id: Int
    var kind: DrawingKind
    var visible = true
    var position = DrawingPoint(x: 0, y: 0)
    var size = DrawingSize(width: 100, height: 60)
    var from = DrawingPoint(x: 0, y: 0)
    var to = DrawingPoint(x: 100, y: 60)
    var color = DrawingColor.white
    var transparency = 0.0
    var thickness = 1.0
    var filled = false
    var radius = 34.0
    var text = ""
    var textSize = 18.0
    var centered = false

    var opacity: Double {
        1 - min(max(transparency, 0), 1)
    }
}

import SwiftUI

struct DrawingCanvasView: View {
    @EnvironmentObject private var store: DrawingStore

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(Color(red: 0.055, green: 0.07, blue: 0.09))
                Canvas { context, size in
                    drawGrid(in: &context, size: size)
                    for object in store.objects where object.visible {
                        draw(object, in: &context)
                    }
                }
                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
            .overlay {
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(Color.white.opacity(0.08), lineWidth: 1)
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
        }
        .accessibilityLabel("Drawing preview canvas")
    }

    private func drawGrid(in context: inout GraphicsContext, size: CGSize) {
        var path = Path()
        let spacing: CGFloat = 24
        stride(from: CGFloat.zero, through: size.width, by: spacing).forEach { x in
            path.move(to: CGPoint(x: x, y: 0))
            path.addLine(to: CGPoint(x: x, y: size.height))
        }
        stride(from: CGFloat.zero, through: size.height, by: spacing).forEach { y in
            path.move(to: CGPoint(x: 0, y: y))
            path.addLine(to: CGPoint(x: size.width, y: y))
        }
        context.stroke(path, with: .color(.white.opacity(0.045)), lineWidth: 0.5)
    }

    private func draw(_ object: DrawingObject, in context: inout GraphicsContext) {
        let color = Color(
            red: object.color.red,
            green: object.color.green,
            blue: object.color.blue
        ).opacity(object.opacity)
        let lineWidth = CGFloat(max(0.5, object.thickness))
        let position = CGPoint(x: CGFloat(object.position.x), y: CGFloat(object.position.y))
        let rect = CGRect(
            origin: position,
            size: CGSize(
                width: CGFloat(max(0, object.size.width)),
                height: CGFloat(max(0, object.size.height))
            )
        )

        switch object.kind {
        case .line:
            var path = Path()
            path.move(to: CGPoint(x: CGFloat(object.from.x), y: CGFloat(object.from.y)))
            path.addLine(to: CGPoint(x: CGFloat(object.to.x), y: CGFloat(object.to.y)))
            context.stroke(path, with: .color(color), lineWidth: lineWidth)
        case .square:
            let path = Path(rect: rect)
            if object.filled {
                context.fill(path, with: .color(color))
            } else {
                context.stroke(path, with: .color(color), lineWidth: lineWidth)
            }
        case .circle:
            let circleRect = CGRect(
                x: position.x,
                y: position.y,
                width: CGFloat(max(0, object.radius * 2)),
                height: CGFloat(max(0, object.radius * 2))
            )
            let path = Path(ellipseIn: circleRect)
            if object.filled {
                context.fill(path, with: .color(color))
            } else {
                context.stroke(path, with: .color(color), lineWidth: lineWidth)
            }
        case .text:
            let text = Text(object.text)
                .font(.system(size: CGFloat(max(8, object.textSize)), weight: .medium, design: .monospaced))
                .foregroundColor(color)
            context.draw(text, at: position, anchor: object.centered ? .center : .topLeading)
        case .triangle:
            var path = Path()
            path.move(to: CGPoint(x: rect.midX, y: rect.minY))
            path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY))
            path.addLine(to: CGPoint(x: rect.minX, y: rect.maxY))
            path.closeSubpath()
            if object.filled { context.fill(path, with: .color(color)) }
            else { context.stroke(path, with: .color(color), lineWidth: lineWidth) }
        case .quad:
            var path = Path()
            path.move(to: CGPoint(x: rect.minX + rect.width * 0.16, y: rect.minY))
            path.addLine(to: CGPoint(x: rect.maxX, y: rect.minY + rect.height * 0.14))
            path.addLine(to: CGPoint(x: rect.maxX - rect.width * 0.16, y: rect.maxY))
            path.addLine(to: CGPoint(x: rect.minX, y: rect.maxY - rect.height * 0.14))
            path.closeSubpath()
            if object.filled { context.fill(path, with: .color(color)) }
            else { context.stroke(path, with: .color(color), lineWidth: lineWidth) }
        }
    }
}

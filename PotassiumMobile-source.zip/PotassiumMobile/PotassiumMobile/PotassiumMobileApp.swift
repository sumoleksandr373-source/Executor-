import SwiftUI

@main
struct PotassiumMobileApp: App {
    @StateObject private var drawingStore = DrawingStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(drawingStore)
                .preferredColorScheme(.dark)
        }
    }
}

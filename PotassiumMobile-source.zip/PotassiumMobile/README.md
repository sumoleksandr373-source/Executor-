# Potassium Mobile

An iOS Luau playground with a native SwiftUI Drawing preview. It executes user-authored Luau in an isolated VM owned by this app and draws objects inside its own Canvas. It does not attach to, inject into, inspect, or modify another app or game process.

## What is included in this first source drop

- SwiftUI app shell with Editor, Drawing, and Files tabs.
- Native Canvas renderer for Line, Square, Circle, Text, Triangle, and Quad.
- Luau bridge built against the official Luau VM and compiler (pinned to release 0.748).
- Each run uses its own sandboxed Luau thread with the app's Drawing helpers exposed as globals.
- Drawing API: `Drawing.new`, object property writes, `Remove`/`Destroy`, `isrenderobj`, `getrenderproperty`, `setrenderproperty`, and `cleardrawcache`.
- Basic `Vector2.new` and `Color3.fromRGB` values.
- Execution source-size limit (128 KB), 512-object limit, 2-second VM interrupt, a 64 MB VM allocation ceiling, and removal of file, OS, debug, module-loading, dynamic-loading, and coroutine globals from the script environment.
- Save and reload `Untitled.luau` from the app's Documents/Scripts directory.

## Build prerequisites

- macOS with Xcode 15 or newer and Xcode Command Line Tools.
- CMake (`brew install cmake`).
- XcodeGen (`brew install xcodegen`).

## Build

From this directory:

```sh
./Scripts/verify-source.sh
./Scripts/build-luau-ios.sh
xcodegen generate
open PotassiumMobile.xcodeproj
```

Select an iPhone simulator or a connected iPhone, then Build/Run from Xcode. For a physical device, configure signing with your own Apple development team in Xcode.

The Luau dependency is fetched from the official `luau-lang/luau` repository at release tag `0.748` by the build script and built as static libraries for iPhoneOS and iOS Simulator. The upstream project documents `Luau.VM` + `Luau.Compiler` as the embedding libraries and requires separate compile/load steps for source execution. `verify-source.sh` performs source-level checks; it does not replace the Xcode build.

## Drawing example

```lua
local square = Drawing.new("Square")
square.Position = Vector2.new(40, 40)
square.Size = Vector2.new(120, 70)
square.Color = Color3.fromRGB(70, 160, 255)
square.Thickness = 2
square.Filled = false

print(isrenderobj(square))
print(getrenderproperty(square, "Thickness"))
setrenderproperty(square, "Visible", true)
```

## Compatibility note

The uploaded Madium data contains documentation strings for the four helper functions above, not the implementation of the original Drawing renderer. This app therefore implements its own in-app renderer and a documented starter subset. It should not be described as full compatibility with any third-party executor until individual properties and edge cases are verified.

## Current verification status

The project sources are prepared. This environment does not include Xcode or an iOS SDK, so an iOS app build, code signing, simulator launch, and on-device run cannot be verified here. Run the build steps above on a Mac to complete those checks.

## Build an unsigned IPA without owning a Mac

This repository includes `.github/workflows/build-unsigned-ipa.yml`. GitHub Actions runs the build on a hosted macOS machine; no local Xcode installation is required.

1. Create a GitHub repository and upload the **contents** of this project folder (including the hidden `.github/workflows` folder). Keep the repository private if you do not want the source public.
2. Open the repository's **Actions** tab and enable Actions if GitHub asks.
3. Select **Build unsigned iOS IPA**, press **Run workflow**, and start the run.
4. When it finishes successfully, open the run, find **Artifacts**, and download `PotassiumMobile-unsigned-IPA`.
5. Extract the downloaded artifact. It contains `PotassiumMobile-unsigned.ipa`.
6. Import that IPA into ESign and sign it with a certificate (`.p12`) and a matching provisioning profile (`.mobileprovision`) that permit this app's bundle ID `app.potassium.mobile` and the target device.

**Important:** the workflow deliberately creates an unsigned IPA. It is a build package, not an install-ready signed app. ESign still needs valid signing credentials and a provisioning profile that covers the device. Do not upload `.p12` files, private keys, or provisioning profiles to the repository. The free Apple Personal Team has short-lived provisioning (7 days) and device/app limits; see Apple's account overview.

The workflow itself cannot verify installation on the iPhone. A successful GitHub Actions run proves the cloud build and packaging completed; signing and on-device launch must be checked separately.
